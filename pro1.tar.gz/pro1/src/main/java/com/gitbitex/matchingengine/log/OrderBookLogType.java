package com.gitbitex.matchingengine.log;

public enum OrderBookLogType {
    RECEIVED,
    OPEN,
    MATCH,
    DONE,
}
