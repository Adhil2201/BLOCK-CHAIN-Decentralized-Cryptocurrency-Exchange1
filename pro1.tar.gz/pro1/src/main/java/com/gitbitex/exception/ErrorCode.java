package com.gitbitex.exception;

public enum ErrorCode {
    INSUFFICIENT_BALANCE,
    DUPLICATE_BILL_ID,
}
