package com.gitbitex.openapi.model;

public class SendCodeRequest {
    private String type;
    private String email;
}
